package com.backend.inventoryXpert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryXpertApplicationTests {

	@Test
	void contextLoads() {
	}

}
